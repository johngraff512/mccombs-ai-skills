# McCombs Case Toolkit 1.3.2 — ChatGPT Installation

This is a distribution bundle, not a multi-skill upload. Unzip it first, then install each `skill.zip` separately.

Recommended order:
1. `01-case-idea-generator/skill.zip`
2. `02-case-generator/skill.zip`
3. `03-case-factcheck/skill.zip`
4. `04-teaching-note-generator/skill.zip`
5. `05-class-exercise-generator/skill.zip`
6. `06-slide-generator/skill.zip`
7. `07-case-refresher/skill.zip`

After installation, use natural prompts such as ‘Fact-check this case’ or explicitly name the McCombs skill.
